# WOLF15 — A00: integrasi PR berbasis revision set

Audit read-only 8 September 2026. Repo tunggal `tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM`. Main diamati kembali pada commit `1837f4b7cbded620c35933af980e9abd166de39e`, tree `4a687c6669d9ed7d0da48cc5b20fcc005b2ad59a`.

**Verdict integrasi: HOLD untuk menyatakan combined release siap. A00 kini menghasilkan resolusi desain konkret, tetapi combined commit, build, dan pengujian belum dibuat/dijalankan.** Pilihan efisien adalah satu baseline main dengan dua workstream terbatas: D0 engineering dari #419, serta strategi SHADOW dari #418. Gabungkan keduanya setelah kontrak dan schema diselesaikan. #418 tidak perlu menjadi penghambat engineering D0; engineering D0 juga tidak membuktikan kesiapan strategi alami.

## 1. Yang benar-benar diperiksa

Semua metadata changed files diperoleh untuk enam PR: **54 pasangan PR/path, 52 path unik**. Setiap daftar satu halaman berukuran kurang dari 100 dan jumlahnya cocok dengan `changed_files` metadata PR. Sebanyak 53 patch tersedia dan hitungan baris tambah/hapus cocok dengan metadata. Server tidak menyertakan patch dokumen #414; full source diambil pada head tepat dan Git blob-nya diverifikasi. Tidak ada diff yang diam-diam dianggap lengkap ketika patch kosong.

**68 rekaman full source** direkonstruksi/diambil lalu dicocokkan dengan Git blob SHA, termasuk 33 migration main, tiga tambahan migration PR, protokol pada tiga head dan satu base, EA DEMO beserta include SHADOW, serta source tambahan. Identitas file terverifikasi tidak berarti semua file mendapat review semantik penuh: **18 entri PR/path mendapat inspeksi semantik pada scope eksplisit; 36 lainnya metadata/acquisition only**. Ledger `pr-path-coverage.json` menyebut scope per file. Worker lain menangani strategi dan eksekusi secara terpisah; ledger ini tidak mengklaim coverage milik worker lain.

Tiga pemeriksaan `git merge-file --stdout --diff3` dijalankan pada file ekspor yang tepat, dengan input SHA-256, argv, exit code, dan hash output dicatat. Ini analisis tiga file, **bukan** merge repository, merge-tree lengkap, checkout combined, atau penerapan patch. Source masukan tidak ditulis ulang. Hasilnya:

| Kombinasi | File | Hasil terukur |
|---|---|---|
| #418 + #419, common protocol base sama dengan main | `contracts/mt5_execution_protocol.py` | 8 region konflik tekstual, exit 8 |
| main + #418, base #418 | `tests/test_strategy_5scr_tradeplan_candidate_v2_containment.py` | 1 region konflik tekstual, exit 1 |
| #413 + #415, common base | `tests/test_startup_migration_ownership.py` | 1 region konflik tekstual, exit 1 |

Dengan bukti ini status berkembang dari sekadar `OVERLAP_DETECTED` menjadi **konflik tekstual yang terkonfirmasi pada scope file tersebut**. Itu belum membuktikan keseluruhan PR tidak kompatibel secara perilaku; resolusi semantik tetap memungkinkan.

## 2. Revision set dan kedudukan PR

Semua enam PR masih open dan unmerged pada refresh ini. #414 non-draft; yang lain draft. Kolom mergeable hanya hasil komputasi GitHub individual pada base PR masing-masing.

| PR | Head commit lengkap | Base PR lengkap | Ahead/behind main | Mergeable | Peran |
|---|---|---|---|---|---|
| #413 | `f5cd076b86e5bc3ed22242f75a896ef453871d90` | `7c45484e9124bb4a8a745dc1ef8832a7745ea58c` | 1/9 | true | Release exact SHA khusus pressure-outbox |
| #414 | `dd27ae87d0207466caad4c3e098224112ac0eaf7` | `7c45484e9124bb4a8a745dc1ef8832a7745ea58c` | 1/9 | true | Dokumen V3.1; bukan aktivasi runtime |
| #415 | `128472045277632b3a091086c5fd1b7cbdf40549` | `7c45484e9124bb4a8a745dc1ef8832a7745ea58c` | 14/9 | true | Repair fixtures dan pemisahan correctness/performance |
| #416 | `2ee5239ec0e029805c54b364d973f33c5674e9e7` | `128472045277632b3a091086c5fd1b7cbdf40549` | 15/9 | true | Satu commit unik health-probe di atas #415 |
| #418 | `a28ee83b838df259f89a87153f16d2c4cac3dc92` | `7c45484e9124bb4a8a745dc1ef8832a7745ea58c` | 1/9 | false | C2 projection → manual C3 SHADOW |
| #419 | `3f4b8293c6c70b010bbbb85306379ba54079e125` | `7b00ec0bba7763f347cf6de0381468999c4ace29` | 4/2 | true | Satu engineering DEMO canary |

Compare exact #415→#416 menegaskan ahead 1, behind 0, merge-base sama dengan head #415; delta unik hanya launcher dan test launcher. Jangan mengaplikasikan seluruh #416 lalu menerapkan #415 lagi.

Reviews yang tersedia: #414 mempunyai satu `COMMENTED` dari connector, lainnya daftar kosong. Ini bukan approval. Commit-status API memberi `Vercel=failure` untuk semua head; **status itu tidak membuktikan kegagalan source WOLF15 maupun Railway**. Checks API/job result lengkap tidak dikumpulkan ulang dalam workstream ini, sehingga required-check readiness tetap NOT_MEASURED. Main `protected=false`; ruleset yang terlihat `13682266` berstatus disabled. Status mergeable tidak menggantikan gate tersebut.

## 3. Resolusi protokol #418 + #419

Keduanya mengubah union `ExecutionCommandV1.source`, union `guards`, validator `_validate_command_shape`, constants, dan export list. Mengambil `ours` atau `theirs` untuk seluruh file menghapus salah satu kemampuan. Menggabungkan union tanpa validator pasangan source/guards juga tidak cukup.

Resolusi yang direkomendasikan:

1. Pertahankan empat kelas sumber: existing `CommandSource`, `ShadowAcceptanceSource`, `ShadowProjectionCommandSource`, dan `EngineeringDemoCanarySource`. Pertahankan empat kelas guard dan pemeriksaan pasangan sumber/guard terpisah. Jangan menambahkan generic DEMO/LIVE melalui fallback branch.
2. Pertahankan validator #418: projection hanya `SHADOW`, action `PLACE_MARKET` sebagai rehearsal, guard khusus projection, empat authority flags false, lineage candidate/authority konsisten. Pertahankan validator #419: hanya DEMO, exact executor/account/server/symbol, satu market order, parent, magic `150016`, prefix `W15D0:`, GTC tanpa expiry broker, guard canary khusus.
3. Jalur dispatch harus memilih berdasarkan source class/schema, mode, dan guard. **`source_event` saja tidak cukup:** #418 sengaja memakai `signal_json`, yang juga dipakai source strategi existing. #418 bahkan memakai `valid_for_execution=true`, `execution_gate_passed=true`, `tradeplan_valid=true` sebagai kosakata kompatibilitas mekanis EA SHADOW, sambil mengunci authority flags false. Satu boolean tersebut tidak boleh menjadi izin universal di consumer baru.
4. Untuk evolusi berikutnya, gunakan discriminator command class yang tidak ambigu dan versioned contract. Jangan mengganti format signed bytes secara diam-diam. `SIGNED_WIRE_VERSION` dan domain HMAC tidak berubah pada kedua diff; preserve exact canonical payload bytes selama kompatibilitas protocol v2 dipertahankan.
5. Pemeriksaan negative union minimal: projection diberi DEMO/LIVE; canary diberi SHADOW/LIVE; source projection dengan guard canary; source canary dengan guard risk; existing signal dengan guard projection; source_event `signal_json` tetapi schema projection/hybrid fields; unknown fields; stale/revoked binding; class yang benar namun signature/payload diubah. Setiap penolakan harus diverifikasi sampai **nol insertion/claim/broker dispatch**, bukan hanya validasi Pydantic.

Perubahan #419 pada `next_command` dan `claim_command` secara eksplisit membatasi mode DEMO kepada `ENGINEERING_DEMO_CANARY` dengan window ARMED. Karena itu **#418 + #419 belum menyediakan natural strategy DEMO**. Membuka mode itu memerlukan consumer/producer/kontrak risk/EA yang terpisah dan diuji, bukan sekadar menambahkan anggota union atau mengganti flag.

Sumber primer: [protokol #418](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/a28ee83b838df259f89a87153f16d2c4cac3dc92/contracts/mt5_execution_protocol.py), [protokol #419](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/3f4b8293c6c70b010bbbb85306379ba54079e125/contracts/mt5_execution_protocol.py), [repository #419](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/3f4b8293c6c70b010bbbb85306379ba54079e125/execution/mt5_command_repository.py).

## 4. Migration DAG dan semantic dependency

Seluruh 33 migration main dibaca sebagai AST untuk `revision/down_revision/depends_on/branch_labels`; tiga migration tambahan ikut dihitung. Header merupakan source data, tidak diimport atau dijalankan. Hasil tidak memiliki parent hilang pada scope ini:

| Set source | Jumlah revision | Head yang terhitung |
|---|---:|---|
| main | 33 | `20260822_01` |
| main + #419 | 34 | `20260823_01` |
| main + #418 | 35 | `20260813_04`, `20260822_01` |
| main + #418 + #419 | 36 | `20260813_04`, `20260823_01` |

Cabang dari `20260813_02` ialah projection `20260813_03→20260813_04`, dan observer `20260822_01→DEMO 20260823_01`. Perbedaan filename tidak menghindarkan kebutuhan convergence.

Review SQL memberi alasan konkret untuk desain additive:

- Observer migration membuat schema `observer_export`, stream heads dan immutable outbox. Pada migration tersebut tidak ditemukan penambahan kolom `execution_commands`.
- Projection `20260813_03` membuat table proyeksi dengan FK lineage lengkap ke CandidateV2 dan snapshot akun. `20260813_04` bergantung pada table tersebut, menambah kolom projection yang **nullable tanpa global false defaults** ke `execution_commands`, membuat issuance table, FK, unique constraints, dan trigger atomic/immutable.
- DEMO `20260823_01` menambah tiga kolom canary yang berbeda, mengganti dua check lineage v1 menjadi v2, serta membuat window table dan unique index satu open/unresolved canary. Jalur `signal_json` v2 mempertahankan source signal id/hash; projection #418 menggunakan jalur itu dan mempunyai check/trigger tambahan sendiri.
- Secara source, keluarga kolom/constraint tambahan berbeda dan terdapat desain agar command non-projection memiliki kolom projection NULL. **Ini mendukung kandidat kompatibilitas, bukan PASS PostgreSQL.** Mengisi projection flags false sebagai defaults untuk semua command justru melanggar cabang NULL bagi command non-projection.
- Setelah #419, `shadow_acceptance_schema_status()` mencari nama check v2. Menjalankan binary #419 dengan schema v1 dapat membuat readiness menolak. Migration/binary deployment wajib terikat satu manifest dan urutannya diuji.
- Kedua downgrade baru mempunyai guard penolakan bila ledger terkait masih berisi command/issuance. Rollback setelah broker effect tidak boleh disamakan dengan `alembic downgrade` atau menghapus ledger agar guard lolos; utamakan kill/containment, reconciliation, dan forward repair.

Pilihan migration:

| Kondisi yang dibuktikan | Pilihan |
|---|---|
| Engineering D0 terlebih dahulu, #418 belum diperlukan | Gunakan chain main→#419 yang secara source sudah satu head. Tidak perlu memasukkan branch proyeksi ke D0 |
| Kedua history sudah pernah diaplikasikan atau applied state belum diketahui | Pertahankan revision IDs/parent history; rancang additive merge revision dengan parent kedua head dan remediation migration berikutnya bila constraints perlu diubah |
| Semua environment relevan terbukti belum pernah memakai migration unpublished #418 | Reparent/resequence branch unpublished dapat dipertimbangkan setelah inventory; bukan asumsi default |

**Applied database heads belum diamati.** Karena itu belum dipilih migration mutation final. Next read-only evidence: `alembic_version` dan schema/constraint inventory dengan role audit pada database target, tanpa DSN/credential di laporan. Kemudian uji disposable database dari fresh base dan setiap supported applied head, termasuk data command existing dan kedua urutan upgrade yang didukung. Source DAG saja tidak membuktikan upgrade/downgrade berhasil.

## 5. Dua konflik kecil yang harus diselesaikan dengan benar

**Candidate containment main/#418.** Konflik terletak pada allowlist consumer CandidateV2. Main menambah `OBSERVER_PROJECTION_FILE` dengan komentar source-verbatim telemetry; #418 menambah tiga modul proyeksi contracts/analysis/storage. Resolusi harus mempertahankan keduanya dengan role berbeda, serta semua negative scans. Menghapus observer untuk meloloskan #418 menghilangkan pekerjaan main; menghapus projection membuat feature #418 tak lengkap. Daftar allowlist yang lebih panjang tidak membuktikan authority terjaga; test observer tetap read-only dan projection tetap inert perlu dijalankan.

**Migration test #413/#415.** #413 memperbaiki assertion launcher untuk wrapper redacting migration runner dan menambah source-string assertions. #415 memperluas ownership ke semua startup script dan menguji pemanggilan Alembic, exit code 23, serta redaksi output secara perilaku. Resolusi praktis: pertahankan behavior tests #415 dan release-governance tests #413; deduplikasi assertion yang hanya memeriksa detail implementasi. Jangan drop exit propagation/redaction coverage saat memilih sisi konflik.

**Health probe #416.** Return type `start_probe_in_thread` berubah dari `HealthProbe` menjadi `HealthProbeRuntime`. Handle sekarang mengakses probe melalui `.probe` serta memiliki `.stop/.join/.close`. Delta PR hanya launcher/tests. Audit caller produksi harus memastikan retained handle tidak memanggil API lama dan lifecycle service benar-benar menutup resource. Perubahan signature terbukti; broken caller belum terbukti dalam workstream ini.

## 6. Manifest integrasi yang disarankan

`pr-integration-revision-set.json` memisahkan empat set. Tidak satu pun mengklaim combined SHA telah ada.

1. **Minimal functional D0:** main + #419 + independent attestation + clock/recovery correction + bukti isolasi startup/broker paths + source/config/schema/artifact binding. #414 dan #418 bukan functional predecessor.
2. **Set release/evidence D0:** tambahkan #413, #415, lalu delta unik #416, dengan resolusi migration test. Total candidate changed path unik 37. #415/#416 membantu memenuhi repo-native gates; jangan menganggap semua file test itu dependency runtime broker. #413 hanya memiliki release surface pressure-outbox; API/bridge/orchestrator/EA membutuhkan release binding yang sesuai target masing-masing.
3. **Strategy SHADOW:** main + #418 + keputusan policy/hash + repair freshness/timeout/ownership yang ada di jalur aktif + lifecycle wiring + migration convergence dengan observer. PR #414 adalah sumber dokumen; status approval user dan deployment activation harus direkam sebagai hal berbeda.
4. **Natural strategy DEMO:** convergence source kedua set, resolved protocol/DAG, deterministic capital-risk adapter CandidateV2, command/EA/lifecycle untuk strategi alami, serta bounded account acceptance. Tidak ada pintasan otomatis dari manual SHADOW projection atau non-strategy canary ke tahap ini.

Hard dependencies: #415→unique #416; observer migration→DEMO migration; projection03→projection04; producer+consumer union→protocol conformance; applied-head inventory→pemilihan schema-release mutation. Soft order: baseline evidence work mendahului broad clean-runner acceptance. #414 dan ingest strategy dapat dikerjakan paralel dengan D0, dengan owner file berbeda.

Compile input closure D0 wajib mencakup `Wolf15_DumbExecutor_Demo.mq5` **dan** file yang di-include `Wolf15_DumbExecutor_Shadow.mq5` blob `84e73471fd26eb1f1b81da11f15146e3735a6c52`. DEMO merename event handlers sebelum include lalu menyediakan handler aktif sendiri. Hash satu file DEMO saja tidak mengikat binary yang dikompilasi. Perubahan perbaikan shared transport nantinya memerlukan recompile kedua artifact dan parity tests; mengganti timer SHADOW tidak otomatis mengganti handler DEMO.

## 7. Acceptance konkret sebelum menyebut integrasi selesai

| Bukti | Kondisi lulus yang harus diobservasi |
|---|---|
| Combined source | Satu commit/tree nyata; selected deltas dan resolusi conflict tercatat; current main observer/dashboard tidak hilang |
| Protocol | Semua class positif sesuai mode; cross-class/advisory/unknown/stale negatif; exact signed bytes parity Python–EA |
| PostgreSQL | Satu selected schema head; fresh upgrade dan supported upgrade histories; existing SHADOW, projection dan canary rows valid; SQL-invalid rows ditolak |
| Concurrency | Dua issue/retry/conflicting identity tak menghasilkan command kedua; no duplicate claim/effect; kill/reports/reconciliation dapat maju tanpa deadlock |
| Compiler | Both exact EA artifacts compile; include closure bound; actual executable hashes dan compiler build tercatat |
| Clean runner | Native gates exit/log tersimpan pada combined SHA; skips/unexecuted diungkap; timing observational tidak menghapus correctness gates |
| Runtime binding | Deployed source/image/config/schema/account/server/executor tepat; current flags/service topology dilihat langsung |
| D0 | Attestation independen valid, quote fresh, maksimum satu submit/effect, outcome direkonsiliasi; event ini tidak masuk scorecard strategi |

Semua baris ini masih **NOT_EXECUTED atau NOT_MEASURED untuk combined target** dalam workstream A00. Historical PASS di body PR tidak dijumlahkan menjadi combined PASS.

## 8. Governance, batas skill, dan handoff

GitHub Multi-Repo skill diterapkan pada exact PR revision set dan overlap/dependency review. Namun `governance-envelope-v1` bawaannya mensyaratkan minimal dua repository unik, sedangkan task ini satu repository dengan enam PR. Membuat dua identitas semu untuk repo yang sama juga ditolak kontrak manifest. Karena itu **bundled envelope validator NOT_EXECUTED**, alasan tercatat; tidak ada klaim PASS dari validator tersebut. Dipakai envelope dokumenter satu repo `pr-governance-envelope.json`, dengan semua source-edit/commit/push/merge/deploy/database/broker flags false. Ini keterbatasan schema, bukan hambatan untuk menyelesaikan review.

Artefak utama: `pr-integration-revision-set.json`, `pr-path-coverage.json`, `pr-migration-dag.json`, `pr-diffs/three-way-text-analysis.json`, raw API receipts beserta full patch, dan `pr-source/source-manifest.json`. Hash input/output tersedia untuk reproduksi analisis.

Next authorized action adalah menggunakan desain resolusi ini untuk rencana/patch terisolasi pada combined baseline sesuai scope implementasi yang ditugaskan owner; sebelum tindakan eksternal, refresh refs yang terlibat. Workstream ini berhenti pada review read-only. Tidak ada perubahan repository, merge/push, deployment, migration database, attachment EA, maupun order.
