"""Read-only pure raw-block probe. Synthetic data, no service or broker imports."""
import importlib.util
import sys
import json
import hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path

root = Path(__file__).resolve().parent
source = root / 'strategy-source/analysis/strategy_5scr_raw_admission_blocks.py'
spec = importlib.util.spec_from_file_location('_wolf15_raw_probe', source)
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)
t = datetime(2026, 9, 8, tzinfo=timezone.utc)
def event(offset, side, symbol='EURUSD'):
    return dict(timestamp=t+timedelta(seconds=offset), symbol=symbol,
                event_type='THROTTLED', source_stream='RAW_THROTTLED',
                pressure_source='SignalThrottle', eligible_for_pressure_block=True,
                throttled_inferred_direction=side, deployment_id='synthetic-main-probe',
                scanner_cycle_id='fixture-'+str(offset), suppressed=0)

fixtures = {
    'aligned_300_seconds': [event(0,'BUY'),event(150,'BUY'),event(300,'BUY')],
    'same_symbol_conflict_300_seconds': [event(0,'BUY'),event(150,'SELL'),event(300,'BUY')],
    'gap_301_seconds': [event(0,'BUY'),event(301,'BUY')],
    'identical_delivery_100_times': [event(0,'BUY')]*100,
    'same_second_cross_symbol': [event(0,'BUY'),event(.1,'BUY','GBPUSD'),event(.2,'BUY')],
}
out=[]
for name, events in fixtures.items():
    result=m.build_raw_admission_population(events)
    out.append(dict(name=name, input_count=len(events), raw_count=len(result.events),
                    duplicates=result.duplicate_event_count, blocks=[b.to_dict() for b in result.blocks]))
assert [b['duration_seconds'] for b in out[0]['blocks']] == [300.0]
assert [b['duration_seconds'] for b in out[1]['blocks']] == [0.0,0.0,0.0]
assert out[2]['blocks'][0]['finalization_reason']=='MAX_GAP_EXCEEDED_EVENT'
assert out[3]['raw_count']==1 and out[3]['duplicates']==99
assert len(out[4]['blocks'])==3
print(json.dumps(dict(scope='EXACT_MAIN_RAW_BLOCK_PURE_MODULE_SYNTHETIC_FIXTURES',
 source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
 note='No full PairAdmission integration; verifies builder only. Never market data or broker outcome.',
 cases=out),indent=2))
