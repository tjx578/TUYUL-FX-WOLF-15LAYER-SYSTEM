"""Isolated diagnostics for the attached SignalThrottle source, not a repo test suite.

Loads the uploaded Python declarations and standard-library imports via AST.
Unavailable project imports are NOT loaded or simulated wholesale. A narrowly
scoped direction-normalization double supports only the literal test values.
Record methods use a capture sink, avoiding log emission, persistence and all
external systems. No order, network or database operations are performed.

Usage: python reproduce_findings.py --source 'Pasted text(9).txt' --output results.json
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import sys
import types
from collections import Counter, deque
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from unittest.mock import patch


def load_declarations(source: Path) -> tuple[types.ModuleType, str, ast.Module]:
    raw = source.read_bytes()
    text = raw.decode('utf-8-sig')
    tree = ast.parse(text, filename=str(source))
    # Syntax compilation only; this does not import/execute the whole package.
    compile(tree, str(source), 'exec')
    safe_nodes: list[ast.stmt] = []
    for node in tree.body:
        if isinstance(node, ast.Import):
            if not all(n.name.split('.')[0] in sys.stdlib_module_names for n in node.names):
                raise ValueError('Unexpected third-party top-level import')
            safe_nodes.append(node)
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or '').split('.')[0]
            if node.level == 0 and (root == '__future__' or root in sys.stdlib_module_names):
                safe_nodes.append(node)
        elif isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.Assign, ast.AnnAssign)):
            safe_nodes.append(node)
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            safe_nodes.append(node)
        elif isinstance(node, ast.Try):
            # Uploaded source's normalize_direction relative-import fallback only.
            if not all(isinstance(n, ast.ImportFrom) for n in node.body):
                raise ValueError('Unexpected top-level try block')
        else:
            raise ValueError(f'Unexpected top-level node {type(node).__name__}')
    module = types.ModuleType('_wolf15_attached_declarations')
    sys.modules[module.__name__] = module
    exec(compile(ast.Module(body=safe_nodes, type_ignores=[]), str(source), 'exec'), module.__dict__)

    def normalize_direction_double(direction: Any, verdict: Any = None) -> str | None:
        # Not a replacement for schemas.direction; only a controlled test input adapter.
        allowed = {None, '', 'WAIT', 'NO_TRADE', 'BUY', 'SELL', 'EXECUTE_BUY', 'EXECUTE_SELL',
                   'EXECUTE_REDUCED_RISK_BUY', 'EXECUTE_REDUCED_RISK_SELL'}
        for value in (direction, verdict):
            value = value.upper() if isinstance(value, str) else value
            if value not in allowed:
                raise ValueError(f'Untested normalization input: {value!r}')
            if value in {'BUY', 'SELL'}:
                return value
            if isinstance(value, str) and value.startswith('EXECUTE_'):
                return value.rsplit('_', 1)[-1]
        return None

    module.normalize_direction = normalize_direction_double
    return module, hashlib.sha256(raw).hexdigest(), tree


def run(source: Path) -> dict[str, Any]:
    m, digest, tree = load_declarations(source)
    t = datetime(2026, 9, 8, 0, 0, tzinfo=UTC)  # Synthetic test timestamp, NOT market evidence.
    results: list[dict[str, Any]] = []

    def capture(method: str, **kwargs: Any) -> list[Any]:
        events: list[Any] = []
        sink = types.SimpleNamespace(_record_runtime_event=events.append)
        getattr(m.SignalThrottleLiveAnalyzer, method)(sink, **kwargs)
        return events

    def parsed(event: Any) -> Any:
        result = m.parse_signal_throttle_row({
            'timestamp': event.timestamp.isoformat(), 'severity': event.severity, 'message': event.message,
        })
        if result is None:
            raise AssertionError('Parser unexpectedly returned None')
        return result

    # Exact record method + exact local block builder: HOLD retains pressure.
    throttled = capture('record_throttled', symbol='USDJPY', timestamp=t)[0]
    block = m.build_scanner_cycle_pressure_blocks([throttled])[0]
    assert (throttled.effective_action, throttled.eligible_for_execution,
            throttled.eligible_for_pressure_block, block.effective_ticks) == ('HOLD', False, True, 1)
    results.append({'id': 'D01', 'classification': 'SUPPORTED_BEHAVIOR',
                    'observation': 'THROTTLED remains pressure evidence while execution flag is false',
                    'effective_action': throttled.effective_action, 'eligible_for_execution': False,
                    'eligible_for_pressure_block': True, 'effective_ticks': block.effective_ticks})

    # Exact record/parser paths disagree for allowed non-execute verdicts.
    allowed = capture('record_allowed', symbol='USDJPY', verdict='NO_TRADE', timestamp=t)[0]
    offline_allowed = parsed(allowed)
    assert allowed.eligible_for_execution is True and offline_allowed.eligible_for_execution is False
    results.append({'id': 'D02', 'classification': 'REPRODUCED_FLAG_PARITY_DEFECT',
                    'input_verdict': 'NO_TRADE', 'live_execution_flag': True, 'parsed_execution_flag': False})

    # Same canary observations disappear from the scanner-block lane on parsing.
    live_canary: list[Any] = []
    for offset in (0, 150, 300):
        live_canary.extend(capture('record_pressure_canary', symbol='USDJPY', direction='BUY',
                                   timestamp=t + timedelta(seconds=offset)))
    offline_canary = [parsed(e) for e in live_canary]
    live_blocks = m.build_scanner_cycle_pressure_blocks(live_canary)
    offline_blocks = m.build_scanner_cycle_pressure_blocks(offline_canary)
    offline_pure = m.build_pure_pressure_blocks(offline_canary)
    assert len(live_blocks) == 1 and live_blocks[0].duration_seconds == 300
    assert len(offline_blocks) == 0 and len(offline_pure) == 1
    results.append({'id': 'D03', 'classification': 'REPRODUCED_PRESSURE_PARITY_DEFECT',
                    'synthetic_observations': 3, 'live_scanner_blocks': 1,
                    'live_duration_seconds': 300, 'parsed_scanner_blocks': 0,
                    'parsed_pure_blocks': 1,
                    'scope': 'Does not test canonical raw admission or advisory maturity policy'})

    # One source call emits two representations, both counted by this lane.
    pair = capture('record_throttled', symbol='USDJPY', verdict='EXECUTE_SELL', timestamp=t,
                   count=6, remaining=0, max_signals=5, window_seconds=60)
    pair_block = m.build_scanner_cycle_pressure_blocks(pair)[0]
    assert len(pair) == 2 and pair_block.events == 2 and pair_block.effective_ticks == 2
    results.append({'id': 'D04', 'classification': 'REPRODUCED_COUNTING_HAZARD',
                    'source_calls': 1, 'emitted_event_types': [e.event_type for e in pair],
                    'scanner_event_count': 2, 'scanner_effective_ticks': 2,
                    'scope': 'Counts emission rows, not proven independent pulses; raw-admission dedupe not tested'})

    # Test exact insertion method with a controlled equal-key boundary.
    sink = types.SimpleNamespace(_events=deque(), _event_keys=deque(), _retention_guard=None,
                                 _canonical_event_key=lambda event: (event.timestamp, 'identical-source-key'))
    m.SignalThrottleLiveAnalyzer._insert_event_canonically_locked(sink, throttled)
    m.SignalThrottleLiveAnalyzer._insert_event_canonically_locked(sink, throttled)
    duplicate_block = m.build_scanner_cycle_pressure_blocks(list(sink._events))[0]
    assert len(sink._events) == 2 and duplicate_block.effective_ticks == 2
    results.append({'id': 'D05', 'classification': 'REPRODUCED_MISSING_BUFFER_DEDUPE',
                    'distinct_input_events': 1, 'deliveries': 2, 'buffer_rows': 2,
                    'effective_ticks': 2, 'double': 'Equal canonical key supplied; original ID helper unavailable'})

    # No grant means false in the exact raw-only helper; no advisory input exists.
    eligible = m._pair_eligible_for_analysis(pair_admission_grants=[], as_of_utc=t)
    assert eligible is False
    results.append({'id': 'D06', 'classification': 'SUPPORTED_RAW_ONLY_BOUNDARY',
                    'pair_admission_grants': [], 'pair_eligible_for_analysis': eligible,
                    'scope': 'No advisory maturity evaluator is present/tested in this function'})

    # Exact quorum ignores timestamps; declared default window is 120 seconds.
    distant_allowed: list[Any] = []
    for offset in (0, 600, 1200):
        distant_allowed.extend(capture('record_allowed', symbol='USDJPY', verdict='EXECUTE_BUY',
                                       timestamp=t + timedelta(seconds=offset)))
    quorum = m.compute_allowed_quorum(distant_allowed)
    assert quorum['streak'] == 3 and quorum['quorum_reached'] is True
    results.append({'id': 'D07', 'classification': 'REPRODUCED_QUORUM_WINDOW_GAP',
                    'event_offsets_seconds': [0, 600, 1200], 'declared_default_window_seconds': 120,
                    'actual_quorum': quorum})

    # Conflicting directional observations become a majority/first-tie label.
    sides = [m.SignalThrottleLogEvent(timestamp=t, severity='info', message=side,
                                      symbol='USDJPY', event_type='INTEL', direction=side)
             for side in ('BUY', 'SELL')]
    first = m._dominant_direction(sides)
    reverse = m._dominant_direction(list(reversed(sides)))
    assert first == 'BUY' and reverse == 'SELL'
    results.append({'id': 'D08', 'classification': 'REPRODUCED_DIRECTION_SUMMARY_AMBIGUITY',
                    'input_votes': {'BUY': 1, 'SELL': 1}, 'buy_first_result': first,
                    'sell_first_result': reverse,
                    'scope': 'Legacy summary is not a v3.1 ALIGNED lineage proof'})

    # Explicit as-of API admits a future event: upper age bound only.
    future = m.SignalThrottleLogEvent(timestamp=t + timedelta(seconds=60), severity='info',
                                      message='future fixture', symbol='USDJPY', event_type='INTEL', direction='BUY')
    inherited = m.resolve_microboost_direction({'symbol': 'USDJPY'}, events=[future], now=t)
    assert inherited['inherited_direction'] == 'BUY'
    results.append({'id': 'D09', 'classification': 'REPRODUCED_AS_OF_HELPER_GAP',
                    'decision_time': t.isoformat(), 'evidence_time': future.timestamp.isoformat(),
                    'resolution': inherited,
                    'scope': 'Explicit-now helper only; normal caller is flag-gated default OFF'})

    # Legacy pure block explicitly ignores another symbol within the same second.
    interleaved = [m.SignalThrottleLogEvent(timestamp=t + timedelta(milliseconds=offset),
                    severity='info', message=f'fixture {offset}', symbol=symbol,
                    event_type='THROTTLED', eligible_for_pressure_block=True)
                   for offset, symbol in [(0, 'USDJPY'), (100, 'EURUSD'), (200, 'USDJPY')]]
    pure = m.build_pure_pressure_blocks(interleaved)
    usd = [b for b in pure if b.symbol == 'USDJPY']
    assert len(usd) == 1 and usd[0].events == 2
    results.append({'id': 'D10', 'classification': 'SUPPORTED_LEGACY_BLOCK_SEMANTICS',
                    'input': ['USDJPY@0ms', 'EURUSD@100ms', 'USDJPY@200ms'],
                    'usdjpy_pure_blocks': 1,
                    'scope': 'This is not the separately imported canonical raw-admission builder'})

    # Raw log sampling drops distinct same-key events; this is not source dedupe.
    later_throttled = capture('record_throttled', symbol='USDJPY', timestamp=t + timedelta(seconds=10),
                              count=99)[0]
    with patch.dict(m.os.environ, {}, clear=True):
        sample_seconds = m._signal_throttle_raw_sample_seconds()
        with patch.object(m, '_SIGNAL_THROTTLE_RAW_SAMPLE_LAST', {}):
            with patch.object(m.time, 'time', side_effect=[1000.0, 1010.0]):
                emitted_first = m._signal_throttle_raw_sample_allowed(throttled)
                emitted_second = m._signal_throttle_raw_sample_allowed(later_throttled)
    assert sample_seconds == 60.0 and emitted_first is True and emitted_second is False
    assert throttled.suppressed == later_throttled.suppressed == 0
    results.append({'id': 'D11', 'classification': 'REPRODUCED_SAMPLED_EXPORT_LIMITATION',
                    'default_sampling_seconds': sample_seconds, 'distinct_source_events': 2,
                    'first_log_eligible': emitted_first, 'second_log_eligible': emitted_second,
                    'suppressed_counters_after_sampling': [throttled.suppressed, later_throttled.suppressed],
                    'scope': 'In-memory recording is before sampling; full durable raw ledger not inspected'})

    local_names = sorted(node.name for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef)))
    literals = ['StrategyAnalysisAdmission', 'MATURE_ADVISORY', 'CANONICAL_RAW',
                'PressureDirectionalHypothesis', 'PairAdmissionCoverage', 'microboost_pulse_event_id']
    text = source.read_text(encoding='utf-8-sig')
    return {
        'scope': 'UPLOADED_FILE_ONLY_ISOLATED_DIAGNOSTICS',
        'source_file': source.name,
        'source_sha256': digest,
        'physical_lines': len(text.splitlines()),
        'syntax_compile': 'SUCCESS_SYNTAX_ONLY',
        'diagnostic_count': len(results),
        'observations': results,
        'literal_presence': {name: name in text for name in literals},
        'local_top_level_definitions': len(local_names),
        'test_doubles': ['normalize_direction for controlled literals',
                         '_record_runtime_event capture sink (no logging/storage)',
                         'equal canonical key for insertion duplicate test'],
        'not_executed': ['Full module import with real project dependencies',
                         'Canonical raw-admission helpers', 'Maturity policy registry',
                         'Repository suite, Ruff, Pyright', 'Durable lifecycle/outbox integration',
                         'Railway runtime verification', 'Broker operations'],
        'production_readiness_verdict': 'NOT_ASSESSED_BY_ISOLATED_TESTS',
        'source_modified': False,
        'ssot_modified': False,
        'timestamps_note': 'All prices/directions/timestamps are synthetic fixtures; no historical USDJPY market evidence is used',
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path('/mnt/data/Pasted text(9).txt'))
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('diagnostics.json'))
    args = parser.parse_args()
    try:
        report = run(args.source)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        print(json.dumps(report, indent=2, ensure_ascii=False))
    except (OSError, SyntaxError, ValueError, AssertionError) as exc:
        print(f'Diagnostic run failed: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
