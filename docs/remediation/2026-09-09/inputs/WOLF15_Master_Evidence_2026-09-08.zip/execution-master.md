# WOLF15 — konsolidasi execution, risk, authentication, dan pemulihan akun

Status pekerjaan: **SOURCE REVIEW + PROPOSED IMPLEMENTATION BACKLOG**. Implementasi, test repo, MetaEditor, PostgreSQL/Redis runtime, Railway, dan broker: **NOT_EXECUTED**. Skill `agent-authentication` diterapkan untuk threat model, flow contract, control gaps dan acceptance. Dokumen merupakan masukan ke program perbaikan root; bukan perubahan source atau perintah trading.

Rekomendasi utama: pertahankan signed execution plane, PostgreSQL authority, HTTPS pull dan EA mekanis. Bangun sambungan natural 5S-CR yang memang belum tersedia pada kontrak yang diperiksa. Pecah rollout menjadi D0 engineering, D1a parent alami, lalu D1b child; setiap tahap mempunyai kontrak, bukti dan batas sendiri. D1a mempercepat pembuktian end-to-end, tetapi tidak menyelesaikan requirement parent-child pada produk akhir.

## 1. Sumber primer dan cakupan

Main diperiksa pada `1837f4b7cbded620c35933af980e9abd166de39e`; candidate #418 pada `a28ee83b838df259f89a87153f16d2c4cac3dc92`; candidate #419 pada `3f4b8293c6c70b010bbbb85306379ba54079e125`. **12 file, 332.857 byte, 12/12 Git blob cocok** setelah fetch baru. Identitas per file ada pada `execution-source-manifest.json`. Ini bukan checkout atau audit semua file repo. Metadata current main ditangani root; candidate refs adalah exact review subject, tidak diasumsikan merged atau deployed.

Dokumen sekunder yang dikonsolidasikan: `auth-attestation.md`, `runtime-architecture.md`, `code-debt-disposition.md` dalam integration evidence bundle; `ea_contracts.md` dan `risk_roadmap.md` dalam paket bukti lanjutan; serta `WOLF15_Lanjutan_Assessment_dan_Rancangan_Perbaikan_2026-09-08.md`. Claim historis dipertahankan sebagai historis; pembacaan ulang kode dibedakan dari hasil uji.

| Evidence ID | Exact primary source | Fakta yang dikonfirmasi |
|---|---|---|
| ES01 | [Main risk request](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/1837f4b7cbded620c35933af980e9abd166de39e/contracts/strategy_5scr_risk_reservation.py#L35) | Request menerima `5scr-plan`, PARENT saja; policy literal `5scr.production-adjusted.parent-only.v1`. |
| ES02 | [Main reserve_parent](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/1837f4b7cbded620c35933af980e9abd166de39e/storage/strategy_5scr_risk_reservation_repository.py#L364) | Transaksi mengunci executor/governance/account; SHADOW dan kill engaged wajib; kandidat diambil dari store lama; hanya open_positions diperiksa pada batas flat. |
| ES03 | [Main signed producer](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/1837f4b7cbded620c35933af980e9abd166de39e/execution/mt5_risk_command_producer.py#L281) | Producer SHADOW saja, strict latest snapshot equality, durable outbox dan command binding; command dibuat SHADOW pada L408. |
| ES04 | [Main P5 v2](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/1837f4b7cbded620c35933af980e9abd166de39e/analysis/strategy_5scr_tradeplan_candidate_v2.py#L582) | Identitas `5scr-tradeplan-v2` berbeda dari ES01. |
| ES05 | [#418 projection contract](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/a28ee83b838df259f89a87153f16d2c4cac3dc92/contracts/strategy_5scr_shadow_risk_projection.py#L1) | C2 projection bukan capital reservation; `execution_authority`, `capital_reserved`, `broker_side_effect_allowed`, `order_send_eligible` literal false pada L161–164. |
| ES06 | [#418 projection repository](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/a28ee83b838df259f89a87153f16d2c4cac3dc92/storage/strategy_5scr_shadow_risk_projection_repository.py#L163) | Persistensi projection tersendiri; validasi active candidate/proof dan predecessor; tidak menyentuh capital reservation/outbox. |
| ES07 | [#418 C3 promotion](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/a28ee83b838df259f89a87153f16d2c4cac3dc92/execution/mt5_shadow_projection_command_promotion.py#L1) | Fungsi murni, manual/operator wiring; hanya signed SHADOW PLACE_MARKET. |
| ES08 | [#419 canary builder](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/3f4b8293c6c70b010bbbb85306379ba54079e125/execution/mt5_engineering_demo_canary.py#L112) | DEMO canary engineering non-strategy, minimum volume, fresh reconciled flat snapshot, dedicated EA. |
| ES09 | [#419 DEMO EA](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/3f4b8293c6c70b010bbbb85306379ba54079e125/ea_interface/wolf15_executor/Wolf15_DumbExecutor_Demo.mq5#L441) | Menolak strategy authority dan risk reservation fields; persist submit marker L949–959; `OnTimer` quote-clock L1227. |
| ES10 | [#419 command repository](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/3f4b8293c6c70b010bbbb85306379ba54079e125/execution/mt5_command_repository.py#L392) | Menyimpan snapshot executor; enqueue L876–914 dan arm L1131–1170 membaca boolean reconciliation dari snapshot tersebut. |
| ES11 | [Main executor auth](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/1837f4b7cbded620c35933af980e9abd166de39e/api/middleware/executor_auth.py#L15) | Derived bearer per executor, current/previous roots, minimum secret length, constant-time comparison; bukan proof isi telemetry. |
| ES12 | [Main wire protocol](https://github.com/tjx578/TUYUL-FX-WOLF-15LAYER-SYSTEM/blob/1837f4b7cbded620c35933af980e9abd166de39e/contracts/mt5_execution_protocol.py#L434) | Canonical payload bytes, per-executor derived HMAC verification key, versioned preimage, payload digest dan envelope verification sudah ada. |

## 2. Apa yang benar-benar kurang

**#418 + #419 tidak otomatis menjadi natural DEMO.** #418 membuktikan perhitungan *would reserve* dan delivery SHADOW. #419 sengaja mengecualikan strategy/risk lineage. Main reserve/producer juga masih SHADOW. Mengganti mode atau regex akan melewati kontrak yang semula membatasi authority.

Sambungan minimal yang dibutuhkan:

`current canonical P5 revision → capital risk admission DEMO → frozen FinalSignal → signed natural DEMO command → bound mechanical EA → broker observations → independent reconciliation → account risk state`.

P5 non-executable tetap non-executable sampai risk + final decision authority yang berlaku membentuk FinalSignal. Advisory, historical highest-authority, UI state, hasil riset, dan #418 projection tidak boleh menciptakan reservation atau command natural DEMO sendiri. Implementasi baru sebaiknya memakai helper validasi lineage/decimal/signed-wire existing dan menambah versi authority yang eksplisit. Hindari protokol kedua hanya untuk mengganti nama.

As-is belum membuktikan natural market/limit/supersede/child lifecycle tersedia. C3 #418 hardcodes market + GTC; canary #419 juga market only. Kontrak natural harus menambahkan order type yang benar untuk strategi, termasuk waktu tunggu pending, cancel target dan race fill bila retracement limit didukung. Jangan memakai market canary sebagai proxy pengujian pending-order strategy.

## 3. Keputusan efisien yang disarankan

| Area | Keputusan praktis | Alasan dan batas |
|---|---|---|
| Transport EA | Tetap outbound HTTPS pull dengan timer monotonic; prioritaskan pending report/recovery sebelum pickup baru | Sudah ada. Tidak perlu EA WebSocket atau Kafka untuk menyelesaikan bug correctness. Data ingest WS adalah jalur berbeda. |
| Database authority | PostgreSQL untuk risk, intent, command, submit status, reconciliation dan audit; Redis untuk cache/projection | Memakai fondasi existing dan menghindari Redis→PG dual-write authority F17. Satu migration owner dan dependency graph ditentukan root. |
| Proses | Gunakan existing bridge/engine/trade/orchestrator roles dengan satu producer per scope, tanpa service baru per tabel | Nama deployment owner harus cocok entrypoint; orchestrator hanya lifecycle dan tidak mengambil alih risk/strategi. Runtime topology belum diukur. |
| DEMO pertama alami | D1a satu akun DEMO, satu executor, allowlist instrumen terikat spec broker, parent only; order mode yang didukung diuji eksplisit | Membatasi domain recovery. Ini tahap rollout, bukan perubahan permanen strategi atau klaim complete 5S-CR. Jangan menetapkan persentase risk baru melalui dokumen teknis. |
| Child | D1b setelah lifetime role slot, broker-linked parent, residual-risk semantics dan policy profile selesai | Mempertahankan final goal parent-child; floating profit dengan SL statis tidak dianggap risk release. |
| Crypto | Pertahankan wire HMAC per executor yang sudah ada; distinct credentials issuer/executor/attestor, bounded rotation dan key IDs | ES12 sudah menyelesaikan sebagian saran generic signing dokumen lama. Ed25519/KMS/Vault bukan prerequisite otomatis. Pilih asymmetric hanya bila threat model/deployment mendukung dan interoperabilitas diuji. |
| Reconciliation | Collector read-only + principal berbeda + append-only proof + backend verifier, dapat memakai tool/channel existing yang benar-benar tersedia | Tidak perlu membangun broker API baru jika reader yang ada mampu membaca account lengkap. Ketersediaan reader, permission broker dan host independence masih unknown. |
| Refactor | Perbaiki atau isolasi jalur aktif, kemudian ekstrak helper shared dengan parity test | Rewrite menyeluruh atau penambahan agen riset tidak menutup execution gap dan memperlebar regression surface. |

Public-key verification mengurangi kebutuhan membagikan key yang juga dapat menandatangani, tetapi tidak membuat laporan broker benar. HMAC per executor membatasi scope key; jangan mengklaim terminal compromise menjadi aman. Untuk DEMO terbatas, pemisahan credential/write authority dan independent read adalah kontrol inti. Root signing secret tidak dibagikan ke terminal. Saran penggantian signing stack hanya layak setelah source/operational need jelas.

## 4. Kontrak natural DEMO yang konkret

Nama di bawah adalah **usulan kontrak**, gunakan nama field existing bila semantik cocok. `wolf15.strategy-5scr.natural-demo-command.v1` harus dibedakan dari canary `ENGINEERING_DEMO_CANARY` dan C3 SHADOW. Versi baru ditolak oleh EA lama; jangan downgrade otomatis.

| Kelompok | Field/invariant minimum | Owner |
|---|---|---|
| Scope | `source_class=NATURAL_5SCR`, mode DEMO, strategy version/digest, risk policy version, account binding version, expiry/bounded rollout ID | Backend configuration/governance |
| Lineage | Event/raw canonical ID, lifecycle/context/thesis/box IDs, candidate ID+revision+material/evidence hashes, active eligibility | Strategy/P5 repository |
| Risk | Durable reservation ID, risk authorization version, snapshot ID+hash, broker spec digest, verified reconciliation ID, campaign/leg ID, role, locked risk basis/budget, final planned cash loss | Account risk authority |
| Order | Frozen action, canonical+broker symbol, side/type, volume, entry/reference, SL, full TP1, fill policy, broker pending expiry and time-in-force | Final builder; EA rejects unsupported representation |
| Envelope | Stable intent key, immutable command ID/revision/hash, existing signed-wire envelope, executor/session binding, claimed payload hash, claim lease | Producer + command repository |
| Timing | Source as-of, issued/not-before, submit deadline, pending deadline anchored to strategy event, snapshot captured/received | Backend; transport retry cannot reset strategy window |
| Guards | Current account/server/DEMO, permitted margin mode, fresh quote, spread/drift, attached protections, exact supported spec, account budget, governance version | Backend admission plus EA mechanical revalidation |
| Reports | Command/hash/attempt ID, event ID/sequence, broker retcode/tickets/deals, requested/filled/remaining volume, observed clocks, durable unresolved reason | EA outbox; independently verified outcome |

Risk policy is not inferred from mode: historical equal5%+5% and DEMO3.5%+1.5% are different versioned policies. A `5scr.production-adjusted.parent-only.v1` identifier on SHADOW main does not prove production capital risk authority. Lock selected account/mode/profile explicitly. Parent-only staging must have explicit `max_child_legs=0` until D1b, preserving a future child gate rather than silently changing final policy.

Implement admission and finalization as bounded transactions:

1. **Transaction A — reserve.** Lock account capacity and current candidate revision; load fresh bound snapshot/spec/reconciliation; check active canonical eligibility, account-wide exposure and policy; claim durable campaign/leg slot; insert risk reservation + immutable FinalSignal + outbox atomically. No network provider/LLM call while account lock held.
2. **Transaction B — publish.** Lock pending outbox/reservation/governance; revalidate eligible versions and latest risk state; create deterministic command ID, signed immutable bytes and binding; update publish disposition atomically. If snapshot is superseded, perform a separately auditable reauthorization or reject with disposition. Never substitute a newer snapshot in an already signed proof.
3. **Transaction C — report/reconcile.** Append idempotent observations; reduce broker entity state and exposure buckets; only verified outcome releases capacity. New activity after command expiry does not reactivate submission.

Current ES03 rejects *any* newer snapshot. This is a conservative guard, not a confirmed live incident. For natural automation it can create repeated `COMMAND_RISK_SNAPSHOT_SUPERSEDED` under heartbeat/queue delay. Measure superseded rate and residence time first; use versioned reauthorization for material account/spec changes and immutable audit linkage. Do not remove freshness gates to improve throughput.

## 5. Data ownership dan lifecycle pemulihan

| Domain | Authoritative state | Writer / consumers | Rule pemulihan |
|---|---|---|---|
| Candidate | Current revision and eligibility plus historical provenance | Engine/P5; risk reads | Historical proof tidak meniadakan expiry/invalidation/revision. |
| Risk admission | Policy, campaign risk unit, lifetime leg slot, reserved/pending/filled/unknown exposure | Risk repository under account lock | Projection/cache tidak meningkatkan headroom. |
| Delivery/action | Prepared/claimed/submit intent/submission unknown/known action result | Command repository; EA reports | Lease expiry tidak membuktikan zero submit. |
| Broker entity | Pending/partial/open position/closed/cancelled remainder/history | Broker read evidence; reconciler reduces | Fill dan command completion berbeda; cancel requested bukan cancelled. |
| Reconciliation | Immutable proof + verifier result/reason/version | Distinct collector principal; backend verifies | Empty/incomplete/stale result → UNKNOWN; no silent overwrite. |
| UI/analytics | Rebuildable status and explanations | Outbox projector/dashboard | UI tidak mengubah authoritative verdict/lot. |

Exposure yang dipakai admission harus non-overlapping: `filled_loss_at_stop + pending_unfilled_risk + reserved_unsubmitted_risk + unknown_submission_risk`. Pemindahan satu bagian volume dari bucket ke bucket dilakukan atomik; tidak dihitung dua kali. Partial fill 40% dari reservation50 berarti filled20+pending30 pada asumsi linear. Confirmed cancel residual melepas30, bukan50. Nilai ini contoh aritmetika, bukan test repo.

EA sequence yang dipertahankan dari #419: verify command + account preflight → durable backend SUBMITTING acknowledgement → revalidate mutable fields after blocking I/O → flush local submit marker → maximum one logical submit → durable observations/reconciliation. Jika crash terjadi setelah marker, mungkin zero atau one broker submission; pemulihan tidak melakukan blind resubmit. Jika terminal lama masih mungkin memegang permit, lease baru sendiri tidak mengotorisasi failover broker.

Lifecycle yang perlu acceptance eksplisit: broker partial fills dan beberapa deal per logical order; parent close sementara child open; cancel-versus-fill; expired delivery tetapi pending broker aktif; order/deal events datang tidak berurutan; duplicate/replayed report; manual trade/account deposit/withdrawal; account/server/session change; kill activated while action ambiguous. Initial dedicated account membatasi interference, tetapi ledger tetap membaca seluruh exposure akun.

`OrderSend=true` belum membuktikan fill; retcode dan broker observations tetap diperlukan. [MetaQuotes OrderSend](https://www.mql5.com/en/docs/trading/ordersend). Handler trade event harus cepat: urutan event tidak dijamin dan queue berukuran terbatas, sehingga tangkap data lokal lalu reconcile tanpa blocking HTTP di handler. [MetaQuotes OnTradeTransaction](https://www.mql5.com/en/docs/event_handlers/ontradetransaction). `WebRequest` sinkron dan tidak berjalan di Strategy Tester; compiler/tester tidak menggantikan terminal integration. [MetaQuotes WebRequest](https://www.mql5.com/en/docs/network/webrequest).

## 6. Authentication threat model dan attestation minimal

Assets: broker account binding, issuer/EA/attestor credential scopes, signed payload, reservation/exposure, submit identity, broker tickets/history, governance. Sensitive sinks: admission, issue/arm, claim/submit, release risk, clear UNKNOWN, enable new risk. Audit scope hanya read-only design.

| Threat/ambiguity | Fakta dan existing controls | Perbaikan minimum |
|---|---|---|
| Executor sah mengirim `broker_ledger_reconciled=true` | ES10 menyimpan snapshot lalu bool dipakai enqueue/arm; token membuktikan executor, bukan independent read. Gate operator/DEMO/flat/signature lain tetap ada. | Heartbeat tidak dapat mengisi verified status; separate attestor ledger, account/purpose/challenge binding, backend computes decision. |
| Replay proof lama / salah akun | Signature hanya membuktikan signed origin | Unique challenge+attestation ID, account/server/executor/purpose/version binding, expiry, atomic one-window association. |
| Collector query failed tetapi positions=[] | Tidak ada proof completeness dari array kosong | Explicit success/errors/coverage untuk orders/positions/history/deals dan watermark. Unknown blocks new risk. |
| Dua terminal memakai executor credential | Scoped token bukan unique process identity | Initial one active terminal; explicit session/permit fence and handoff reconciliation. Broker tidak memverifikasi DB epoch. |
| Key expiry/revocation atau previous key tak berakhir | ES11 current/previous accepted roots tidak memuat TTL sendiri | Document bounded rotation, per-resource revocation on sensitive hops, isolated principal. Jangan melakukan rotasi sebagai bagian audit. |
| Outage setelah accepted order | Local/backend/broker state tidak atomik | Hold unknown exposure, continue evidence/reconciliation; no second submit from timer/retry/lease recovery. |

Attestation minimal: account/login hash/server/DEMO identity, executor and session ID, challenge/purpose, command or preflight window, snapshot/spec/policy hashes, captured/received/end clocks, completeness/errors/watermarks, normalized orders/deals/positions with raw evidence digest, `RECONCILED_FLAT|RECONCILED_EFFECT|UNRESOLVED|CONFLICT|SOURCE_UNAVAILABLE`, attestor credential/key ID and immutable receipt hash. Auth role may submit proofs but cannot issue, arm, alter risk or disable governance. Issuer cannot impersonate attestor through its normal credential. No new endpoint path chosen until existing channel permissions inspected.

A reader on the same compromised host offers limited independence. For initial controlled DEMO, document exact independence boundary and separate write credentials; broader deployment may require separately governed read-only terminal/session. If such source is unavailable, produce `SOURCE_UNAVAILABLE` and finish backend implementation/fixtures; do not insert self-asserted true merely to run D0.

## 7. Backlog implementation terikat dependency

Seluruh baris **PROPOSED / NOT_EXECUTED**. Penamaan file baru illustrative, gunakan repo-native layout. Setiap PR harus kecil dengan contract/tests pada scope yang disentuh; owner below adalah role, bukan orang yang telah ditugaskan.

| Work ID | Perubahan konkret dan scope | Dependency | Acceptance terikat scope | Owner |
|---|---|---|---|---|
| EX01 | Exact integration source, migration DAG, supported route→issuer→sink inventory; isolate legacy producers/risk authority | Root release manifest | One selected schema graph; zero unclassified broker-capable path | Integrator |
| EX02 | Monotonic OnTimer pada shared SHADOW+DEMO scheduler; not-before in atomic claim | EX01 | Frozen quotes tetap heartbeat/recovery; stale quote no submit; before/equal/after temporal guards | EA + bridge |
| EX03 | Separate attestation record/verifier/auth principal; bind enqueue/arm to proof FK/version | EX01 | Forged EA bool/replay/wrong account/incomplete/stale rejected; same proof exact retry idempotent | Auth + ledger |
| EX04 | Canary combined contract/EA/schema/regression and fault recovery | EX02, EX03, release gates | Default off, exact DEMO, marker before submit, crash after acceptance no resubmit, independent outcome | Execution |
| EX05 | Natural DEMO schema and adapter over current P5 candidate; reject projections/advisory/history-only authority | Selected strategy rule/profile, EX01 | Positive canonical current fixture produces valid internal intent; all negative lineage cases zero reservation | Strategy + risk |
| EX06 | Capital risk v2 admission/account ledger; reservation/leg/final signal/outbox in transaction | EX03, EX05 | Concurrent capacity, account isolation, loss oracle, below-min reject, unknown hold; tests on disposable PG | Risk |
| EX07 | Natural signed producer/outbox and report reducer; schema guards and durable recovery | EX06 | Same intent→one command; hash conflict rejects; superseded snapshot explicit reauthorization; published command does not free risk | Trade + ledger |
| EX08 | Natural DEMO EA build using shared transport/journal with explicit source/action allowlist; parent market/limit as selected strategy requires | EX04, EX07 | D0/C3 payload rejected in natural lane; exact request, protections, deadline, partial-fill/cancel/restart tests | EA |
| EX09 | Account reconciliation continuous lifecycle; event capture/report backlog and restart recovery | EX03, EX06–08 | Requested=filled+remaining+cancelled/expired; delay/out-of-order converges; no early release; account switch rejects | Ledger + EA |
| EX10 | D1a end-to-end replay, live SHADOW and bounded natural parent DEMO | Data/strategy gates + EX09 + D0 evidence | Single natural episode lineage to broker outcome; WAIT/advisory/stale zero new-risk command | Release + strategy |
| EX11 | Child policy semantics, lifetime slot, parent risk state proof, campaign caps and child execution | EX10 + selected child policy | Same campaign cannot acquire second lifetime child; partial parent/close race; no floating-profit release shortcut | Risk + strategy |
| EX12 | D1b parent-child soak and REAL readiness review | EX11 + operations/OOS gates | Full intended lifecycle + account-scope loss/recovery observations, separately reviewed promotion | Release/owner |

EX02–03 dapat dikerjakan paralel setelah common contracts dibagi. EX05–06 dapat maju dengan fixture saat broker evidence unavailable; runtime gate tidak dipalsukan. Jangan memblokir semua perbaikan natural pada D0 completion: data/strategy/risk work proceeds in parallel, tetapi efektivitas end-to-end menunggu convergence. EX12 bukan automatic REAL enable.

## 8. Rekonsiliasi dan deduplikasi assessment

| Klaim/saran yang rawan salah gabung | Keputusan konsolidasi | Mapping |
|---|---|---|
| `#418 resolves P5→risk` | Benar untuk C2 projection/C3 SHADOW; belum capital reservation natural | F18; E-01 |
| `#419 ready for strategy once flag enabled` | Salah untuk exact source yang diperiksa: EA sengaja menolak strategy authority dan reservation | E-02 |
| Generic docs belum memiliki canonical signing | Dokumen illustrative kurang rinci, tetapi main ES12 sudah punya exact canonical envelope dan per-executor derivation | E-06; EC10 narrowed |
| Seluruh F12–F17 harus diperbaiki sebelum D0 | Jalur legacy boleh isolasi terbukti; equivalent account/risk guarantees tetap wajib sebelum natural DEMO | E-04; F12–F17 |
| Risk5% berarti campaign5%; DEMO3.5+1.5 memenuhi equal-risk | Keduanya salah: source risk per-entry5+5 berbeda dari asymmetric DEMO; policy selection eksplisit | E-07; R01/R15 |
| Profit parent bisa dipakai sebagai released risk dengan SL tidak berubah | Tidak memenuhi release predicate; jangan menambah BE/trailing sebagai shortcut tersembunyi | E-07; C09/R16 |
| One submit sama dengan one deal/guaranteed fill | Natural partial fill dapat memiliki beberapa deal untuk satu logical order; canary scope tidak otomatis dilonggarkan | E-05; EC06–09 |
| DLL/public-key service/queue baru diperlukan agar EA efisien | Tidak didukung gap saat ini; reuse HTTPS+PG+existing wire, measure first | E-06 |
| Latest heartbeat berarti ready/reconciled/current permission | Telemetry freshness, broker truth, current policy eligibility adalah gate berbeda | E-03/E-08; F07/F11/F15 |

F01–F05/F22 tetap root ownership/release/isolation program. F06–F11/F19 menjadi data/strategy lane prerequisites untuk natural execution. F20–F21 langsung ke EX02. Masalah baru di sini adalah **missing integration capability dan kontrak lifecycle**, bukan 12 bug produksi baru yang direproduksi.

## 9. Pengukuran dan next authorized action

Executed: 12 exact-file fetch and blob verification, directed code/document review, three official MetaQuotes documentation reads. Failed discovery: one guessed nonexistent path returned404; corrected using actual cited producer path/directory metadata. No dependency import, test suite, build, runtime/cloud query, credentials access, broker trade, or source mutation. Source files are read-only audit copies.

Acceptance EX01–EX12 masih NOT_EXECUTED. Throughput, latency, deadline percentile, exposure/position state, collector independence and estimated engineering duration NOT_MEASURED. No performance score or profit claim.

Topology local: one assigned execution/risk/auth analyst; shared primitives reviewed together because same authority boundary. Root owns final plan and resolves strategy/service dependencies against primary source. No additional subdelegation because remaining subtask is coupled and parent already runs independent lanes. Measurement is source coverage, not speedup. Failure case: same EA can self-report reconciliation but true independent reader unavailable; synthesis retains EX03 runtime blocker, continues schema/fixture work, and never labels self-attestation PASS.

Next authorized action: root integrates this backlog with source/policy/service lane outputs, records final selected contract/PR scope and acceptance matrix. This review did not perform a deployment, alter flags or create trading authority.
