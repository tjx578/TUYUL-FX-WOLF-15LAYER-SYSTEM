# Supplement Railway — observasi metadata baru

**Inventory cloud kini berhasil diperiksa**, menutup gap nama/UUID dan recent deployment metadata dalam laporan sumber. Pengambilan: 2026-09-08T18:08:48Z. Project **WOLF-15 LAYER**, `af4d15d8-d4cb-44b7-80e7-d99a37ca0045`; environment **production**, `5838964d-8c76-42b3-b0b9-18f2d1e4d5c2`. Binding dipilih unik dari project authenticated dan cocok project UUID pada lampiran historis. Project lain tidak diperiksa lebih jauh.

Ada **20 service objects**. Daftar50 deployment terbaru mencakup13 service; tujuh yang tidak tercakup diambil latest1 secara spesifik. Tabel memuat deployment terbaru menurut createdAt pada respons, bukan klaim liveness/worker usefulness/execution-ready. SUCCESS tidak berarti task longrunning, D0/P5 sudahlulus, atau broker sudahrekonsiliasi. REMOVED tidak membuktikan alasan removal ataupun semua instance mati.

| Service cloud | Service UUID | Latest deployment metadata | Created at UTC | Commit/image yang diberikan |
|---|---|---|---|---|
| wolf15-runtime-maintenance | `14ae9a1e-7db6-4be7-92eb-8e56f81e7228` | SUCCESS | 2026-09-08T00:34:03.343Z | `ghcr.io/tjx578/wolf15-d1-release@sha256:7a400ba95277b29c27c654eb54e7db9167a5eddb85366845d6beef564e5f5071` |
| wolf15-auditor | `57af3e58-a31b-48b7-8904-371f976d797e` | REMOVED | 2026-09-07T17:51:54.670Z | `ghcr.io/tjx578/wolf15-auditor@sha256:550202aa6cf1d740e9dfc64dc1ebe1a523f471bf1c4dc1e39d470dadc384f788` |
| WOLF15-DASHBOARD-FRONTEND | `b9cd6d24-beae-4211-b475-9b3bfe78b392` | SUCCESS | 2026-09-06T08:46:32.227Z | Tidak tersedia pada metadata |
| wolf15-ea-bridge | `f6403cfe-e50c-4acf-beeb-6f9cd07f0080` | SUCCESS | 2026-09-03T14:49:39.022Z | Tidak tersedia pada metadata |
| wolf15-pressure-outbox | `e555dbb1-76ea-4300-8244-80747cfc9786` | SUCCESS | 2026-09-03T14:51:52.692Z | Tidak tersedia pada metadata |
| verify-and-patch-schema | `06ba09ff-7c27-4db9-8dfb-b40b07ae1ee6` | SUCCESS | 2026-07-07T11:12:55.415Z | `ghcr.io/railwayapp/function-bun:1.3.0` |
| wolf15-signalthrottle-service | `0ca594be-94ba-4328-9ea9-8fe77278a4ec` | SUCCESS | 2026-09-03T04:40:30.429Z | `610d6ebcf548c44488ddeecd33671a7315357ab8` |
| execute-lock-flush | `2830b4c3-e45c-4333-ad44-030fc7ee412c` | SUCCESS | 2026-07-07T11:21:55.791Z | `ghcr.io/railwayapp/function-bun:1.3.0` |
| WOLF15-DASHBOARD | `d6fc5d8c-926d-453c-a93a-c937b4b804fa` | SUCCESS | 2026-09-05T13:48:57.742Z | Tidak tersedia pada metadata |
| wolf15-worker-regime | `80f84085-df8c-46b6-abfc-5ab042840a96` | SUCCESS | 2026-08-14T07:28:47.298Z | `7c45484e9124bb4a8a745dc1ef8832a7745ea58c` |
| wolf15-worker-backtest | `fb1da878-9615-48d1-bad9-b0f7ae497582` | SUCCESS | 2026-08-14T07:28:46.818Z | `7c45484e9124bb4a8a745dc1ef8832a7745ea58c` |
| wolf15-migrator | `8dfa93e2-1e22-4c16-9e28-7160b9dd872b` | SUCCESS | 2026-09-03T12:33:28.121Z | `bbc3205be53e8266243934519b20b1577db305b1` |
| wolf15-api | `d3f53524-4571-496f-8008-b3f98fedc5b9` | SUCCESS | 2026-09-05T13:46:37.678Z | Tidak tersedia pada metadata |
| wolf15-worker-montercarlo | `31ccbb32-8105-41d5-bff7-140b3a990885` | SUCCESS | 2026-08-14T07:28:45.416Z | `7c45484e9124bb4a8a745dc1ef8832a7745ea58c` |
| wolf15-orchestrator | `4492195c-81cd-4e7d-88e8-bf6e380bbcc2` | SUCCESS | 2026-09-05T11:06:43.977Z | `2c099aef5900b30433624c62a3273243f4596437` |
| wolf15-execution | `4300c609-fd97-4eb2-bd13-487c940b5a51` | SUCCESS | 2026-09-03T14:47:43.248Z | Tidak tersedia pada metadata |
| wolf15-engine | `43bc213a-96af-4ed5-b679-691534fad4b4` | SUCCESS | 2026-09-03T14:41:59.981Z | Tidak tersedia pada metadata |
| wolf15-ingest | `e7fb1aa7-2ca0-4287-bd53-35d82181c890` | SUCCESS | 2026-09-03T14:45:28.587Z | Tidak tersedia pada metadata |
| Postgres | `e5ff17c2-ea3c-4a10-b0e6-d5e8054d7f9d` | SUCCESS | 2026-08-26T20:56:25.033Z | `ghcr.io/railwayapp-templates/postgres-ssl:17` |
| Redis | `fd9fe71c-217c-4de7-ad2b-eb64a65f6088` | SUCCESS | 2026-08-11T12:46:40.503Z | `redis:8.6.2` |

**Koreksi praktis terhadap asumsi source-only:**

1. Terdapat existing dedicated orchestrator aktual. Latest deployment metadata menunjukkan commit `2c099aef5900b30433624c62a3273243f4596437`, berbeda dengan audit main `1837f4b7cbded620c35933af980e9abd166de39e`. Ini perbedaan metadata revision, bukan bukti file orchestrator berbeda secara semantic; API embedded owner aktif belum diukur.
2. Tiga cron job terakhir memakai commit `7c45484e9124bb4a8a745dc1ef8832a7745ea58c`; migrator `bbc3205be53e8266243934519b20b1577db305b1`; signalthrottle `610d6ebcf548c44488ddeecd33671a7315357ab8`. Tidak boleh menganggap current main source pasti deployed di semua service. Update timestamp cron tidak membuktikan job mengeluarkan research result.
3. Core API, engine, ingest, execution, bridge, pressure-outbox dan frontend latestmeta tidak menyertakan commitHash/image. **Artifact parity masih belum ditutup.** Jangan mengisi kekosongan dengan SHA main, snapshotId Railway, ataupun commit service lain.
4. `WOLF15-DASHBOARD-FRONTEND` dan `WOLF15-DASHBOARD` adalah dua serviceUUID berbeda. Nama literal dashboard-bff tidak ada; `WOLF15-DASHBOARD` mungkin memegang role BFF sesuai target historis, tetapi entrypoint/source binding belum dibaca. Tidak ada rekomendasi membuat atau menghapus service baru hanya dari nama.
5. Actual spelling MonteCarlo adalah `wolf15-worker-montercarlo`. Registry/release matrix harus memakaiUUID, agar typo nama repo/docs tidak salahtarget. Nama standaloneallocation/genericwolf15-worker tidak ada dalam current list; itu tidak membuktikan role allocation tidak berjalan embedded diTrade.
6. Ada service tambahan `wolf15-runtime-maintenance`, `wolf15-auditor`, `verify-and-patch-schema`, `execute-lock-flush`, `wolf15-signalthrottle-service`. Role mereka tidak tercakup14TOML source. Latest maintenance memakai image digest `sha256:7a400ba95277b29c27c654eb54e7db9167a5eddb85366845d6beef564e5f5071`, sedangkan auditor latestREMOVED memakai `sha256:550202aa6cf1d740e9dfc64dc1ebe1a523f471bf1c4dc1e39d470dadc384f788`. Jangan menganggap release/maintenance selesai P1 hanya dari SUCCESS; attestation image→source+command+output diperlukan.
7. Postgres metadata image `ghcr.io/railwayapp-templates/postgres-ssl:17`, Redis `redis:8.6.2`; ini image label provider, belum runtimeversion query atau config/ACL/restore measurement. Local Compose bukan bukti runtime databaseversion.

**Disposition tambahan yang efisien:** existing auditor menjadi bounded read-only export/audit role jika entrypoint/permissions/output terbukti; runtime-maintenance/schema/lockflush menjadi explicit one-shot maintenance contracts dengan actor/target/reason/expiry/idempotency/receipt. Jangan jadikan maintenance actor selaluaktif atau jalur otomatis menghapus execution locks. signalthrottle service harus dibind sebagai observability/admission role dengan authority none terhadap final risk/order, atau dipensiunkan bila duplicateoutput terbukti. Ini rancangan, bukan fakta fungsi namaservice.

**Langkah berikut:** bind serviceUUID→effective source/root/config/startcommand→artifact digest→role/permissions dan health/output baru pada target existing. Inspeksi resource/log/dataset/broker tidak dilakukan di supplement bounded ini. Tidak adaenv/secrets dibaca dan tidak ada perubahan cloud. Tautan project: [Railway WOLF-15 LAYER](https://railway.com/project/af4d15d8-d4cb-44b7-80e7-d99a37ca0045). Raw structured receipt: `services-railway-observation.json`.

Supplement ini supersedes pernyataan “inventory cloud belumdiperiksa” pada laporan sumber hanya untuk domain metadata yang kini terbukti. Seluruh claim usefulruntime/requiredworker/health/freshness/order tetap NOT_MEASURED. Totalmetadatareadcalls10; broker/mutationcalls0.

