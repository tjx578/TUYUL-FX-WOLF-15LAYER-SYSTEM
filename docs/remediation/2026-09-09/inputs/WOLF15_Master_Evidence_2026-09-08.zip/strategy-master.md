# WOLF15 — Konsolidasi strategi, SSOT, dan risk menuju automatic 5S-CR

Status implementasi yang dinilai: **ANALYSIS_PARTIAL**. Status perbaikan: **PROPOSED / NOT_EXECUTED**. Snapshot source: `1837f4b7cbded620c35933af980e9abd166de39e`; 12 file diambil ulang melalui GitHub dan seluruhnya cocok Git blob. Pemilik sintesis: coordinator; scope worker ini strategi/admission/risk, tanpa edit repo, deployment, database, atau broker. Tanggal receipt mengikuti UTC aktual; 17:54–17:55 UTC pada 8 September sama dengan 01:54–01:55 WITA pada 9 September. Nama paket mengikuti tanggal awal assessment.

**Rekomendasi utama: bangun satu alur natural 5S-CR yang lengkap dengan bukti dari raw event sampai broker outcome. Pertahankan reducer dan durable ledger yang sudah ada; perbaiki admission, policy binding, dan handoff yang terputus.** D0 satu order uji dan natural DEMO merupakan milestone berbeda. Parent-only menjadi scope capability pertama untuk membuktikan natural path; parent+add-on/compounding tetap bagian target, dengan acceptance tersendiri sebelum diaktifkan.

## 1. Pembaruan penting terhadap assessment terdahulu

### S-01 — Source unggahan SignalThrottle terikat ke main setelah normalisasi transport

ZIP review v3.1 hanya memuat report, harness, diagnostics, manifest; tidak memuat `Pasted text(9).txt`. Namun `analysis/signal_throttle_log_analyzer.py` yang diambil dari main mempunyai 4.814 baris, Git blob `82017a4bd9361cdbbeb57b972a696198cc231a25`, SHA256 `8f2f4f9393333abe0ac6d6ded56109b464e1bdb1fe138454e19f9ae15dd2b1b8`. Transformasi yang hanya mengganti LF menjadi CRLF dan menghapus final newline menghasilkan SHA256 unggahan **persis** `77c3e666bd63c0e474ea7afd25ac18fa025d7e9c8014a20d40c9bdf9f061fb55`.

Dengan demikian tidak tepat menganggap temuan review ini berasal dari prototype yang tak terkait repo. Perbedaan yang terbukti adalah representasi newline. Harness yang diperiksa dijalankan ulang pada bytes main asli: **11 diagnostik selesai, exit 0**. Itu berarti perilaku yang dideskripsikan terulang, termasuk defect; bukan 11 tes readiness sistem lulus. Project imports, canonical admission integration, storage, dan broker tidak dijalankan. Receipt mencatat literal normalization double, capture sink, dan controlled equal-key input.

| Review awal | Temuan main yang dikonfirmasi | Status dan dampak yang sah |
|---|---|---|
| F01/D06 | `_pair_eligible_for_analysis` baris3770–3782 raw-grant-only | Observasi dan diagnostik; helper sendiri tidak menerima maturity. Belum membuktikan tidak ada adapter lain di seluruh repo. |
| F02 | Analyzer local deque/candidate snapshot tidak sama dengan durable v3.1 lifecycle | Scope terbatas. **Repo memiliki durable lifecycle V2 dan shadow worker**; jangan menyebut semua lifecycle tidak ada. |
| F03/D02 | `record_allowed`1175 selalu execution flag true, parser332 bergantung verdict | Defect parity direproduksi; NO_TRADE mempunyai flag berbeda. Tidak membuktikan broker order. |
| F04/D03 | Live CANARY1345 pressure true; parser296 false | Tiga fixture live memberi satu scanner block300s; replay memberi nol. Pure/advisory/raw lanes wajib dibedakan. |
| F05/D04 | Satu throttle dengan verdict menghasilkan THROTTLED dan DOWNGRADED, keduanya dihitung | Dua emission rows adalah dua ticks scanner, belum dua independent pulses. Raw IDs juga memasukkan event_type; material-observation reducer harus menghindari inflation. |
| F06/D05 | Insertion1432 menerima key identik; scanner menghitung ulang | Duplicate scanner delivery terulang. **Raw admission builder terpisah sudah dedup exact raw IDs**; jangan menyamaratakan defect. |
| F07/D07 | Quorum4655–4680 tidak mengecek120s yang dideklarasikan | Tiga event0,600,1200s tetap quorum. Jangan konsumsi sebagai v3.1 maturity proof. |
| F08 | Report admission memakai last event time769, activity memakai wall clock1375 | Source-observed stale-as-of inconsistency; feed-silence consumer impact belum diukur. |
| F09/D08 | Majority tie4683–4692 bergantung urutan | BUY/SELL tie label berubah saat urutan dibalik; summary bukan ALIGNED lineage proof. |
| F10/D09 | Resolver3485–3488 menolak terlalu tua tetapi menerima future event | Fixture evidence+60s memberi BUY pada decision sebelumnya; normal caller flag-gated default off. |
| F11/D10 | Pure block same-second interruption bukan raw global block | Legacy pure menyatukan; **raw builder membagi event lintas-symbol0/0,1/0,2s menjadi tiga block**, dikonfirmasi probe baru. |
| F12/D11 | Sample log default60s menghilangkan emission kedua tanpa suppressed increment | Export sampled bukan full raw ledger. Memory record terjadi sebelum sampling. |
| F13 | Hard max-events popleft1466–1469 memotong prefix | Source-observed completeness risk; admission-identity drift belum direproduksi. |

### S-02 — Raw PairAdmission main masih memakai direction sebagai syarat seleksi pair

**Evidence kuat, dampak strategi tinggi bila jalur ini dipakai:** `analysis/strategy_5scr_raw_admission_blocks.py:308–329` memfinalkan block ketika resolved direction berubah; `analysis/strategy_5scr_pair_admission.py:299–300,343–346` menolak direction unresolved/conflicting. Sementara SSOT V2§4.3 dan v3.1§7.3 menyatakan direction consistency bukan syarat pair admission; conflict menurunkan kualitas pressure.

Probe pure module exact-main: satu symbol pada0s BUY,150s SELL,300s BUY menghasilkan **tiga block berdurasi0s**, sedangkan ketiga BUY menghasilkan **satu block300s**. Ini menjelaskan mekanisme loss-of-analysis-coverage yang lebih mendasar daripada sekadar tampilan HOLD. Runtime frequency/kehilangan opportunity belum diukur.

**Patch scope:** versioned raw block reducer, `PairAdmissionGrant` contract, admission evaluator dan tests; direction/quality menjadi atribut evidence, bukan block selection authority. Historical version tetap tersedia untuk replay; jangan mengganti histori. Uji mixed direction≥300s tanpa cross-symbol interruption tetap mendapat evaluation outcome dengan quality conflict; jangan memberi thesis/order otomatis.

### S-03 — Gap source diperlakukan sebagai block baru, belum suspension seperti SSOT

Raw builder315–329 memfinalkan gap>300s dengan `MAX_GAP_EXCEEDED_EVENT`; probe0s/301s menghasilkan dua block. V2§4.2 dan v3.1§7.2 mengharuskan `SUSPENDED_SOURCE_GAP` sampai continuity dapat dibuktikan. Ini **conformance delta terhadap desain**, bukan bukti order salah; marker finalization yang ada masih berguna sebagai historical event.

**Patch:** preserve episode/raw-block identity plus append-only evaluation revisions; gap state membawa missing range, watermark dan recovery reason. Definisikan lateness/deployment-epoch handling secara eksplisit. Acceptance gap→backfill→re-evaluation tidak fork admission, tidak menganggap unknown continuity PASS, dan tidak mengotorisasi candidate historis secara retroaktif.

## 2. Satu strategy contract matrix

Seluruh baris target berikut PROPOSED; nama state konseptual harus dipetakan ke enum existing melalui schema migration, bukan ditambahkan asal pada setiap service.

| Tahap dan owner | Input serta keputusan | State yang diperbolehkan | Handoff dan batas authority |
|---|---|---|---|
| Ingest / evidence owner | Event identity, partition/sequence/epoch, source+received+available time, revision, full coverage | VALID, STALE, GAP, QUARANTINED | Immutable evidence dan watermark; log sampling bukan sumber canonical. |
| Raw admission owner | Global symbol continuity≥300s sesuai policy, cross-symbol boundary, raw lineage lengkap | PENDING_THRESHOLD, EVALUATING, GRANTED, REJECTED, SUSPENDED_SOURCE_GAP, SUSPENDED_LEDGER_GAP | Pair dipilih untuk analisis. Direction conflict tidak menghapus aktivitas pair. Tidak ada lot/order. |
| Strategy analysis admission | Canonical raw grant atau material mature advisory + coverage+direction lineage | CANONICAL_RAW; MATURE_ADVISORY; INSUFFICIENT/INCIDENT | Advisory memperoleh full SHADOW analysis. Risk handoff tetap false. Threshold/maturity policy harus terikat bytes. |
| Lifecycle/evidence scheduler | Episode ID, admission revision, processed watermark dan latest dirty watermark | ANALYSIS_OPEN, WAITING_EVIDENCE, WAITING_PRESSURE_RESOLUTION, transition/terminal states terdefinisi | Satu durable episode. Coalescing mengurangi duplikasi job tanpa menghilangkan material revision yang belum diproses. |
| Pressure hypothesis / context | Mode explicit RADAR_ONLY atau bound CONSOLIDATED_DIRECTION_CONTRACT; H4 context/target | ALIGNED, CONFLICT, INCOMPLETE; ACTIVE/INVALIDATED/SUPERSEDED hypothesis | Summary majority bukan direction contract. LOCKED tidak diinferensikan dari raw BUY. Conflict/separate-route policy ditentukan sebelum replay. |
| Structural engine | Closed H1 sebelum ordered M15 break/accept/retest; M1/tick box; as-of evidence | WAIT, NO_TRADE, thesis ACTIVE, box FROZEN | M15 sebelum H1 confirmation tidak cukup. Evidence yang available setelah decision tidak boleh bocor ke replay. |
| Target-first solver | Nearest fresh H4 target; structural stop; entry constraints; broker geometry/cost | WAIT, NO_TRADE, QUARANTINED, non-executable candidate | SL dahulu sebelum RR interval; net RR dan instrument floor policy. Tidak memilih target lebih jauh demi RR. |
| Risk authority backend | Immutable candidate revision, eligible canonical class, fresh bound account, risk policy, exposure | REJECTED, HELD/RESERVED, EXPIRED, RECONCILIATION_REQUIRED | Atomic check+reserve, campaign/leg/FinalSignal/outbox. Browser dan LLM tidak menyetujui lot. |
| Delivery / bridge | FinalSignal hash+reservation+audience+expiry+revision | QUEUED, CLAIMED, ACCEPTED/REJECTED, submit disposition | Mekanis; signed command bukan signal strategi kedua. Replay/retry memakai identity sama. |
| EA / broker / reconciler | Bound command, exact price/volume/SL/TP, attempt state, broker inventory/history | SUBMIT_ATTEMPTED, SUBMISSION_UNKNOWN, PARTIAL/FILLED/CANCELED/REJECTED, terminal reconciliation | ACK bukan fill; unknown menahan risk dan melarang blind-resubmit. Release parsial sesuai broker proof. |

Highest historical analysis authority dan current risk eligibility adalah field berbeda. Upgrade MATURE_ADVISORY→CANONICAL_RAW wajib re-evaluate pada episode yang sama; kandidat advisory lama tidak cukup diubah boolean. Historical raw grant expiry tidak menghapus jejaknya, tetapi tidak memberikan permission abadi.

## 3. Temuan konsolidasi dan patch scope

| ID | Severity / evidence | Temuan | Patch dan acceptance minimum | Work package disarankan |
|---|---|---|---|---|
| S-04 | HIGH conditional / measured isolated | Normalisasi, scanner dedup/material count dan clock tidak parity | Normalizer tunggal; immutable observation/emission IDs; material pulse reducer; one explicit as-of clock; bounded retention yang dapat dipulihkan. Ulang D01–D11 dengan project dependencies serta restart/live-replay parity. | DATA-ADMISSION |
| S-05 | HIGH natural path / source+document gap | Dual admission v3.1 belum terbukti terhubung; durable V2 sudah ada | Extend existing lifecycle/evidence-owner path, jangan rewrite database ke analyzer. One episode/admission revision/jobs; advisory writes nol risk/command. Uji qualifying advisory→full SHADOW→raw upgrade→fresh candidate. | STRATEGY-V31 |
| S-06 | HIGH / main source confirmed | P5 `5scr-tradeplan-v2:` tidak diterima reservation `5scr-plan:` dan table reader legacy | Versioned adapter/promotion mempertahankan all evidence hashes, policy, state/revision, box, target, cost, authority. Review #418 combined diff sebelum patch. Regex-only migration dilarang karena membuang schema obligations. | NATURAL-HANDOFF |
| S-07 | HIGH candidate conformance / main source confirmed | P5 menghitung gross RR; spread floor tidak sama dengan net RR; FX10pip digunakan langsung tanpa metal policy dispatcher | `strategy_5scr_tradeplan_candidate_v2.py:495–551`; cost contract339–354 estimated spread only. Introduce bound cost/net feasibility model, instrument route and unsupported-symbol reject. Mirror BUY/SELL±tick, positive costs, XAU/JPY tests. Risk revalidation tidak menghapus kewajiban strategy net-RR contract. | STRATEGY-GEOMETRY |
| S-08 | HIGH reachable legacy risk / main source confirmed | RiskEngineV2 account ID memakai RiskManager singleton dengan balance10.000; compliance stub true | Replace authority entry dengan account-bound durable risk service atau quarantine legacy API dari execution. Test dua akun, unavailable snapshot, nonfinite inputs, below-min0 lot, unsupported instrument. Jangan memperbaiki dead route sebagai prerequisite jika isolation terbukti. | RISK-AUTHORITY |
| S-09 | HIGH natural path / main source confirmed | Durable reservation sudah baik tetapi V1 parent-only SHADOW, membutuhkan kill aktif dan flat positions; bukan capability natural DEMO | Preserve PostgreSQL tx/advisory account lock/Decimal/outbox. Add explicitly versioned DEMO mode and pending/unknown exposure reconciliation, target account proof and approved policy; no blanket bypass SHADOW guards. | NATURAL-DEMO |
| S-10 | HIGH policy integrity / documents+memory | Owner menerima arah desain v3.1; active strategy/risk/document/deployment digest belum terikat | Registry terpisah `design_intent`, `approved_doc_digest`, strategy+audit+policy versions, implementation SHA, replay manifest, deployment/mode. Jangan meminta persetujuan desain berulang; capture binding atas keputusan yang sudah ada. | CONTRACT-BASELINE |
| S-11 | HIGH extension / document conflicts | Parent+child equal USD versus DEMO3,5+1,5%; release-parent-risk ambiguous | Separate profiles and capability phases; durable lifetime child slot, full exposure state, specified release definition. Jangan memilih percentage/BE/trailing untuk menutupi ambiguity. | RISK-CAMPAIGN |
| S-12 | HIGH delivery / document state delta | v3.1 Transaction A/B menambah reservation committed before command window | Unique FinalSignal→command, active reservation recheck, reclaim/expiry compensation, immutable terminal reasons. Fault injections crash after A, before/after B, unknown broker, late reports. | NATURAL-HANDOFF |
| S-13 | MEDIUM spec / documents | SSOT examples missing pressure contract version/invalidation/order_type; enum WAITING_PRESSURE_RESOLUTION absent from consolidated enum; route conflict | Generate doc examples/enums from machine contracts. Decision table mode×alignment×domain×proof resolves separate route versus blanket no-thesis. Changes tagged strategy/authority/persistence, not all documentation-only. | CONTRACT-BASELINE |
| S-14 | HIGH validation claims / documents | 9/11 legs and >94% historical not OOS proof; auditV3 still strategyV2 | Dataset+availability+policy+cohort freeze; deterministic replay then OOS with campaign clustering and separate advisory cohort. No win-rate target invented and no WAIT/no-fill counted WIN. | REPLAY-OUTCOMES |

Main source strengths verified: exact raw transport-ID dedup; cross-symbol subsecond boundary; immutable lifecycle V2 contract with execution false and distinct material/continuity clocks; pure P5 structural target selection/stop-before-RR; reservation transaction locks, account snapshot, stable intent/outbox and SHADOW refusal. Full dependencies/runtime readiness remain unmeasured.

## 4. Policy decisions: preserve intent, do not merge incompatible examples

| Item | User/design/source intent | Implementable resolution |
|---|---|---|
| Strategy target | User accepted direction of V3.1 replacement design according to current session memory | Bind exact digest+implementation+policy; preserve approval intent separately from runtime readiness. No claim current Railway is v3.1. |
| RR | Uploaded current strategy documents use1,5; memory also records1:2 | Require exact selected `execution_policy_id`, metric gross/net and version. Candidate evidence points to net1,5; do not silently change active policy by memory or helper default. |
| Target floor | Legacy6pip versus candidate10pip; main P5 fixed10 | 10pip is a rule change, not empirical optimization. Freeze desired policy before comparison; preserve legacy replay. Metals use explicit price-based route, never generic FX pip. |
| Compounding | S03: realized/closed balance basis; campaign unit fixed when parent accepted | New campaign recomputes from latest authoritative closed balance. Floating equity remains safety metric; it does not increase locked campaign R. Withdrawal can block new leg through current account cap. |
| Equal risk | S03: parent5% + child5% of locked base; same USD budget, not same lot | On hypothetical$1.000, budgets$50+$50, cap$100. This is not family-total5%. No runtime adoption inferred. |
| DEMO profile | S12: parent3,5% + child≤1,5%, campaign/account cap5%, released-parent-risk required | This differs from equal-risk. Parent still open+floating profit with unchanged SL does not release loss-at-SL. Explicit policy selection and release definition required; do not inject management rules. |
| Parent-only first capability | Practical phased proposal, not permanent strategy simplification | Natural DEMO one parent position closes full TP1/SL, then extension parent+child. All intended profiles remain documented; add-on disabled until state/risk acceptance available. |
| Netting/hedging | Broker margin mode not observed in this audit | Either enforce declared hedging-only scope or implement virtual legs on aggregate position with deal-based accounting. Never assume one ticket is one leg. |

Final sizing uses positive finite broker-representable values, quantity-step floor, min/max/aggregate volume rules, conservative loss oracle and net costs. Below minimum is reject, never round-up. These are invariants, not guarantees that slippage/gaps cannot exceed planned loss. Loss breach detection blocks additional risk and keeps reconciliation running.

Account exposure accounting target: `filled_loss_at_stop + unfilled_reserved_or_pending_loss + submission_unknown_loss`, with each risk unit in only one bucket during transitions. Avoid subtracting locked profits as risk credit unless portfolio policy explicitly permits it. Atomic account admission prevents two concurrent parents from sharing the same capacity. Partial-fill cancellation releases only broker-confirmed unfilled remainder.

## 5. Fast path and later capabilities

1. **Freeze contract baseline now.** Bind this main and integrated candidate diff, v3.1 design digest, exact executable subset and financial policy choices. Record all existing control statuses separately from target.
2. **Fix source/admission integrity and single-owner wiring in parallel.** S-02/S-03/S-04 remove lost/inflated evidence; durable evaluation watermark means each material update eventually gets one outcome. Add mature advisory using existing lifecycle rather than new analysis platform.
3. **Finish versioned P5→risk→FinalSignal→delivery.** S-06/S-07/S-09/S-12 and final auth/broker reconciliation acceptance are dependencies for natural DEMO. D0 can progress independently once its smaller exact-artifact/account/one-submit controls pass.
4. **Run same frozen episode through deterministic replay and final SHADOW.** Assert counts/identities and every halt reason; do not require market outcome to be profitable merely to prove plumbing. Strategy performance eligibility uses preregistered separate evaluation criteria.
5. **Natural DEMO parent-only on declared account/instrument scope.** Requires source completeness, selected policy, release/mode readiness and reconciled broker results. Completion is a real natural-trigger trace, not a flag being true.
6. **Extend to parent+one child and compounding.** Test child independent structure, immutable budget, lifetime role slot, actual risk release semantics, simultaneous accounts/campaigns, partial fills/restarts before enablement.
7. **REAL readiness later.** Broker execution reliability, out-of-sample evidence, selected financial limits and account/venue readiness require independent results; no quantity or timeframe invented here. Research-worker tuning, richer dashboards, dynamic regime, multi-account scale and LLM enhancements can follow the proven slice.

Acceptance must exercise failures that matter: pressure direction conflict; duplicate transport100×; two emissions one observation; gap+backfill; future availability; stopped feed; advisory upgrade; crash between A/B; expired/superseded reservation; two workers at one capacity; partial fill+cancel; report reversal; callback loss; two executors; balance reduction; broker symbol-spec change. Tests for absent/unselected capability are deferred explicitly, not treated as pass.

## 6. Evidence and coordination handoff

Owned files: this report, `strategy-findings.json`, 12 source files+manifest, two diagnostic receipts/results, normalized-binding receipt, audit boundary envelope/validation. Other agents own service/execution work; no shared source edits. Parent coordinator should merge facts using stable IDs and exact evidence, not average assertions.

Measured: 12/12 Git blob matches; transport normalization digest identity; 11 existing diagnostic cases re-executed; 5 new raw-builder cases. Diagnostic durations are receipts, not benchmarks or parallel-speedup evidence. Not executed: full package imports/suite/type/lint, actual durable risk/admission integration, Railway, database, MT5, broker, OOS. Main tree name scan establishes file existence only; no assertion all v3.1 adapters absent from entire repository.

Failure case resolved: missing historical repo checkout/source upload initially prevented binding; fresh GitHub fetch and normalization SHA match restored binding. Had this failed, uploaded diagnostics would remain HISTORICAL_REPORTED. No need to spawn another worker for this bounded sequential source comparison; root parallel work handles independent service/execution streams.

Next authorized action: root synthesizes combined repair program and acceptance register. Implementation, release and broker effects remain NOT_EXECUTED in this assessment.
